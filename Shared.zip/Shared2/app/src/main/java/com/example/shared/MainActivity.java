package com.example.shared;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button entrar, cadastrar;
    EditText email, senha;
    public static final String TAG = "meuApp";
    public static final String PREF_NAME = "Meu app pref";

    SharedPreferences preferences;
    SharedPreferences.Editor dados;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.i(TAG, "onCreate: Rodando o APP...");
        preferences = getSharedPreferences(PREF_NAME, MODE_PRIVATE);
        Log.i(TAG, "onCreate: pasta Shared criada...");

        dados = preferences.edit();

        initForm();
        cadastrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String sEmail, sSenha;
                sEmail = email.getText().toString();
                sSenha = senha.getText().toString();
                dados.putString("senha",sSenha);
                dados.putString("email", sEmail);
                dados.apply();
            }

        });
        entrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SharedPreferences dados = getSharedPreferences(PREF_NAME, MODE_PRIVATE);
                String sEmail, sSenha;
                sEmail = dados.getString("email","");
                sSenha = dados.getString("senha","");

                String gEmail, gSenha;
                gEmail = email.getText().toString();
                gSenha = senha.getText().toString();

                if( !gEmail.equals(sEmail) || !gSenha.equals(sSenha)){
                    Toast.makeText(MainActivity.this, "Email ou senha invalidos", Toast.LENGTH_SHORT).show();
                }else{
                    Intent intent = new Intent(MainActivity.this, TelaPrincipal.class);
                    startActivity(intent);
                }
            }
        });




    }

    private void initForm() {
        entrar    = findViewById(R.id.btn_entrar);
        cadastrar = findViewById(R.id.btn_cadastrar);
        email     = findViewById(R.id.edit_nome);
        senha     = findViewById(R.id.edit_senha);
    }
}